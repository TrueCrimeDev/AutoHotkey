# Claude Code and ClautoHotkey screenshots

These are unedited captures of actual Claude Code sessions run from C:\ClautoHotkey-Demo. The interpreter, plugin and fixtures use neutral paths. The screenshots were visually checked for personal paths. Share the PNG files in this folder instead of the earlier captures.

- features.png: real script edit, ClautoHotkey validation hook, 26 passing assertions exercising Print, JSON, Inspect, Check, Eval and ProcessPipe, and actual MCP check/server_status calls.
- harness.png: a detail capture of the results portion of the terminal, showing actual static and dry-run gates, coverage and trace. The area containing Python installation discovery is outside the captured region. Static parsing is partial. The raw dry-run stream includes script output and fails the result checker; the separately extracted harness row is accepted. These limitations remain visible.

The executable is a byte-identical copy of the tested build. Raw logs remain local. These screenshots do not establish untested GUI, keyboard/mouse or pure/live harness behavior.